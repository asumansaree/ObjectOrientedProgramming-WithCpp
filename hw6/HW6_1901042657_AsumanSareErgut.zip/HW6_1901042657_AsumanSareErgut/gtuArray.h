#ifndef GTUARRAY_H
#define GTUARRAY_H

#include <iostream>
#include "iterable.h"

namespace ContainerHW6{
	template <class T, int SIZE>
	class GTUArray : public Iterable<T> // Create your own fixed size array
	{
	public:
		GTUArray();
		GTUArray(const GTUArray& object);					//Copy consturctor
		GTUArray& operator=(const GTUArray& rightSide);	//Assigment operator
		~GTUArray();								//Virtual destructor
		bool empty();					//Test whether container is empty
		inline int size() {return size_of_arr;}						//Return container size
		void erase(const T &element);	//Erase element
		void clear();					//Clear all content
		GTUIterator<T> begin();			//Return iterator to beginning
		GTUIterator<T> end();			//Return iterator to end
		GTUIteratorConst<T> cbegin() const noexcept;		
		GTUIteratorConst<T> cend()const noexcept;
		//virtual void addElement(const T &element);	//Insert element	
		T &operator[](int index);	//overloaded []operator.Returns the value given index
		shared_ptr<T> getvaluePtr()const { return arrayPtr; }
		int getSize()const { return SIZE; }
	private:
		shared_ptr<T> arrayPtr;
		int size_of_arr;
	};
}// end of namespace
#endif

