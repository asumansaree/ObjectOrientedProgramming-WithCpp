#ifndef GTUITERATORCONST_H
#define GTUITERATORCONST_H
#include <iostream>
#include <memory>

using namespace std;

namespace ContainerHW6{

	template<class T>
	class GTUIteratorConst
	{
	public:

	    using iterator_category = std::random_access_iterator_tag;
	    using value_type = T;
	    using difference_type = std::ptrdiff_t;
	    using pointer = T*;
	    using reference = T&;

	public:
	    GTUIteratorConst(const T* ptr = nullptr) : _ptr(ptr) {}
	    GTUIteratorConst(const GTUIteratorConst& rightSide) : _ptr(rightSide._ptr) {}
	    
	    T& operator*()  const {return *_ptr;}
	    T* operator->() const{return _ptr;}

	    GTUIteratorConst& operator++()   {_ptr++; return *this;}         //prefix
	    GTUIteratorConst& operator++(int) {GTUIteratorConst temp = *this; _ptr++; return temp;}  //postfix
	    GTUIteratorConst& operator--()   {_ptr--; return *this;}
	    GTUIteratorConst& operator=(const GTUIteratorConst& rightSide) {_ptr=rightSide._ptr; return *this;}
	    //GTUIteratorConst& operator +(int val) {auto i=0; while(i<val){_ptr++; i++; } return *this;}
	    //GTUIteratorConst& operator -(int val){auto i=val-1; while(i>=0){_ptr--; i--; } return *this;}
 	    GTUIteratorConst& operator+(const difference_type& movement){auto oldPtr = _ptr; _ptr+=movement; _ptr = oldPtr; return *this;}
	    GTUIteratorConst& operator-(const difference_type& movement){auto oldPtr = _ptr; _ptr-=movement; _ptr = oldPtr; return *this;}

	    bool operator==(const GTUIteratorConst& rightSide) {return (_ptr==rightSide._ptr);}
	    bool operator!=(const GTUIteratorConst& rightSide) {return (_ptr!=rightSide._ptr);}

	    T* getPtr()const{return _ptr;}


	    operator bool()const
	    {
	        if(_ptr)
	            return true;
	        else
	            return false;
	    }
	    difference_type operator-(const GTUIteratorConst& rightSide){return std::distance(rightSide.getPtr(),this->getPtr());}
	private:
	    const T* _ptr;
	};
}//end of namespace
#endif



/*
#ifndef GTUITERATOR_H
#define GTUITERATOR_H
#include <iostream>
#include <memory>

using namespace std;

namespace ContainerHW6
{
	template<typename T>
	class GTUIteratorConstConst
	{
	public:

	    using iterator_category = std::random_access_iterator_tag;
	    using value_type = T;
	    using difference_type = std::ptrdiff_t;
	    using pointer = T*;
	    using reference = T&;

	public:

	    GTUIteratorConstConst(T* ptr = nullptr){_ptr = ptr;}
	    GTUIteratorConstConst(const GTUIteratorConstConst<T>& rawIterator) = default;
	    ~GTUIteratorConstConst(){}

	    GTUIteratorConstConst<T>& operator=(const GTUIteratorConstConst<T>& rawIterator) = default;
	    GTUIteratorConstConst<T>& operator=(T* ptr){_ptr = ptr;return (*this);}

	    operator bool()const
	    {
	        if(_ptr)
	            return true;
	        else
	            return false;
	    }

	    bool operator==(const GTUIteratorConstConst<T>& rawIterator)const{return (_ptr == rawIterator.getConstPtr());}
	    bool operator!=(const GTUIteratorConstConst<T>& rawIterator)const{return (_ptr != rawIterator.getConstPtr());}

	    GTUIteratorConstConst<T>& operator+=(const difference_type& movement){_ptr += movement;return (*this);}
	    GTUIteratorConstConst<T>& operator-=(const difference_type& movement){_ptr -= movement;return (*this);}
	    GTUIteratorConstConst<T>& operator++(){++_ptr;return (*this);}
	    GTUIteratorConstConst<T>& operator--(){--_ptr;return (*this);}
	    GTUIteratorConstConst<T> operator++(int){auto temp(*this);++_ptr;return temp;}
	    GTUIteratorConstConst<T> operator--(int){auto temp(*this);--_ptr;return temp;}
	    GTUIteratorConstConst<T> operator+(const difference_type& movement){auto oldPtr = _ptr;_ptr+=movement;auto temp(*this);_ptr = oldPtr;return temp;}
	    GTUIteratorConstConst<T> operator-(const difference_type& movement){auto oldPtr = _ptr;_ptr-=movement;auto temp(*this);_ptr = oldPtr;return temp;}

	    difference_type operator-(const GTUIteratorConstConst<T>& rawIterator){return std::distance(rawIterator.getPtr(),this->getPtr());}

	    T& operator*(){return *_ptr;}
	    const T& operator*()const{return *_ptr;}
	    T* operator->(){return _ptr;}

	    T* getPtr()const{return _ptr;}
	    const T* getConstPtr()const{return _ptr;}

	protected:
	    T* _ptr;
	};
}//end of namespace
#endif

*/