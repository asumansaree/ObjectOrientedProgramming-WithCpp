/*File GtuSet.h. 
This is the header file for abstract base class "GTUSet"*/
#ifndef GTUSET_H
#define GTUSET_H

#include <iostream>
#include "iterable.h"

namespace ContainerHW6{
	//Derived class GTUSet from Iterable class
	template <class T>
	class GTUSet : public Iterable<T> {
	public:
		GTUSet();
		GTUSet(int newsetSize);
		GTUSet(const GTUSet& object);					//Copy consturctor
		GTUSet& operator=(const GTUSet& rightSide);		//Assigment operator
		~GTUSet();								//Virtual destructor
		bool empty();					//Test whether container is empty
		int size();						//Return container size
		void erase(const T &element);	//Erase element
		void clear();					//Clear all content
		GTUIterator<T> begin();			//Return iterator to beginning
		GTUIterator<T> end();			//Return iterator to end
		GTUIteratorConst<T> cbegin() const noexcept;		
		GTUIteratorConst<T> cend()const noexcept;
		void addElement(const T &element);	//Insert element
		//bool search(); // Search element in the set	
		//GTUSet my_intersect(GTUSet first1, GTUSet last1, GTUSet first2, GTUSet last2, GTUSet result);
		//GTUSet my_union(GTUSet first1, GTUSet last1, GTUSet first2, GTUSet last2, GTUSet result);
		shared_ptr<T> getsetPtr()const { return setPtr; }
		int getSize()const { return setSize; }
	private:
		shared_ptr<T> setPtr;
		int setSize;
	};
}// end of namespace
#endif
