#include "gtuArray.h"
namespace ContainerHW6
{
	/*no parameter consturctor*/
	template<class T, int SIZE>
	GTUArray<T, SIZE>::GTUArray() 
	{ 	size_of_arr = SIZE;
		//arrayPtr(nullptr);
		shared_ptr <T> temp(new T[size_of_arr],default_delete<T[]>());
		arrayPtr = temp;

	}

	/*copy constructor*/
	template<class T, int SIZE>
	GTUArray<T, SIZE>::GTUArray(const GTUArray<T, SIZE>& object){
		T* temp = new T (SIZE);
		shared_ptr<T> tempptr (temp);

		arrayPtr = tempptr;

		for(int i=0 ; i < SIZE ; ++i)
			arrayPtr.get()[i] = object.arrayPtr.get()[i];
	}
	/*Assigment operator*/
	template<class T, int SIZE>
	GTUArray<T, SIZE>& GTUArray<T, SIZE>::operator=(const GTUArray<T, SIZE>& rightSide){
		if(this == &rightSide)
			return *this;
		T* temp = new T (SIZE);
		shared_ptr<T> tempptr (temp);

		arrayPtr = tempptr;

		for(int i=0 ; i < SIZE ; ++i)
			arrayPtr.get()[i] = rightSide.arrayPtr.get()[i];

		return *this;
	}
	/*Virtual destructor*/
	template<class T, int SIZE>	
	GTUArray<T, SIZE>:: ~GTUArray()
	{
		arrayPtr = nullptr;
	}	

	/*Member function implementations*/	
	//Tests whether container is empty
	template<class T, int SIZE>
	bool GTUArray<T, SIZE>::empty(){
		return (size_of_arr==0);
	}

	/*
	//Inserts element,throws exception if there is a problem	
	template<class T, int SIZE>
	void GTUArray<T, SIZE>::addElement(const T &element){

		//Getting backup of data on variable tempData
		shared_ptr<T> tempData = this->arrayPtr;
		shared_ptr <T, SIZE> temp(new T[++this->SIZE],default_delete<T[]>());
		this->arrayPtr = temp;
		//Copying elements from the temp to the arrayPtr
	    for (int i = 0; i < this->SIZE - 1; ++i)
	        	this->arrayPtr.get()[i] = tempData.get()[i];  

	    //Inserting element to the end of arrayPtr;
	    this->arrayPtr.get()[this->SIZE-1] = element;
	}	
	*/
	//Erase element
	template<class T, int SIZE>
	void GTUArray<T, SIZE>::erase(const T &element){
		int isIn=0;

		GTUIterator<T> p;
		//Looking the set to find if value is in there
		for(p = begin();p != end();++p)
			if(*p == element)
				isIn=1;
				
		//If element is in the set,deletes it
		if(isIn==1){

			shared_ptr<T> temp(new T[size_of_arr],default_delete<T[]>());

			auto j=0;
			//Copying elements to a temporary set
			for( auto i= 0; i< size_of_arr; ++i){
				if(arrayPtr.get()[i] != element){
					temp.get()[j] = arrayPtr.get()[i];
					++j;
				}
			}
						
			arrayPtr= temp;
			//After deleting,decrementing SIZE 
			--size_of_arr;
		
		}
	}	

	//Clear all content	
	template<class T, int SIZE>
	void GTUArray<T, SIZE>::clear(){
		//To clear content arrayPtr and SIZE equalized to 0
		this->arrayPtr=nullptr;
		size_of_arr=0;
	}	

	//Return iterator to beginning
	template<class T, int SIZE>
	 GTUIterator<T> GTUArray<T, SIZE>::begin(){
		return((this->arrayPtr).get());
	}	

	//Return iterator to end
	template<class T, int SIZE>
	 GTUIterator<T> GTUArray<T, SIZE>::end(){
		//To find end of the container adding first adress to SIZE
		return((this->arrayPtr).get()+SIZE);
	}	

	template<class T, int SIZE>
	 GTUIteratorConst<T> GTUArray<T, SIZE>::cbegin() const noexcept{
		return((this->arrayPtr).get());
	}	

	template<class T, int SIZE>
	 GTUIteratorConst<T> GTUArray<T, SIZE>::cend() const noexcept{
		//To find end of the container adding first adress to SIZE
		return((this->arrayPtr).get()+SIZE);
	}	

	//Overloaded []operator.Returns the value given index
	template<class T, int SIZE>
	T& GTUArray<T, SIZE>::operator[](int index)
	{
		if(index > SIZE)
			exit(1);
		//for(auto i=begin(); i<end(); i++ )
	
			return arrayPtr.get()[index];
		
	}			

}//end of namespace