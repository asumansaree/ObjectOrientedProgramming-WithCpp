/*File gtuVector.h. 
This is the header file for abstract base class "GTUVector"*/
#ifndef GTUVECTOR_H
#define GTUVECTOR_H

#include <iostream>
#include "iterable.h"

namespace ContainerHW6
{
	template <class T>
	class GTUVector : public Iterable<T> {
	public:
		GTUVector();
		GTUVector(int new_size);
		//Big three
		GTUVector(const GTUVector& object);					//Copy consturctor
		GTUVector& operator=(const GTUVector& rightSide);	//Assigment operator
		~GTUVector();								//Virtual destructor
		bool empty();					//Test whether container is empty
		int size();						//Return container size
		void erase(const T &element);	//Erase element
		void clear();					//Clear all content
		GTUIterator<T> begin();			//Return iterator to beginning
		GTUIterator<T> end();			//Return iterator to end
		GTUIteratorConst<T> cbegin() const noexcept;		
		GTUIteratorConst<T> cend()const noexcept;
		void addElement(const T &element);	//Insert element	
		const T &operator[]( const int index);	//overloaded []operator.Returns the value given index
		shared_ptr<T> getvaluePtr()const { return vectorPtr; }
		int getSize()const { return vecSize; }

	private:
		shared_ptr<T> vectorPtr;
		int vecSize;
	};
}// end of namespace
#endif