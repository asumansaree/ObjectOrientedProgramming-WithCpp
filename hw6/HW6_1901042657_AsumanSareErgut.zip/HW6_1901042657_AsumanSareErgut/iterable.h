/*FILE gtuContainer.h. 
This is the header file for abstract base class "Iterable"*/
#ifndef ITERABLE_H
#define ITERABLE_H

#include <iostream>
#include "gtuIterator.h"
#include "gtuIteratorConst.h"
#include <stdlib.h>

namespace ContainerHW6{
	//Abstract base class
	template <class T>
	class Iterable{
	public:
		
		/*Member functions*/
		virtual bool empty()=0;							//Test whether container is empty
		virtual int size()=0;							//Return container size
		virtual void erase(const T &object)=0;			//Erase element
		virtual void clear()=0;							//Clear all content
		virtual GTUIterator<T> begin()=0;				//Return iterator to beginning
		virtual GTUIterator<T> end()=0;					//Return iterator to end
		virtual GTUIteratorConst<T> cbegin() const noexcept = 0;		//Return a constant iterator to beginning
		virtual GTUIteratorConst<T> cend()const noexcept= 0;			//Return a constant iterator to end
		/*tters*/
		inline shared_ptr<T> getvaluePtr()const { return valuePtr; }
		inline int getSize()const { return _size; }
	protected:
		shared_ptr<T> valuePtr;
		int _size;

	};
}// end of namespace
#endif