#ifndef GTUITERATOR_H
#define GTUITERATOR_H
#include <iostream>
#include <memory>

using namespace std;

namespace ContainerHW6
{
	template<class T>
	class GTUIterator
	{
	public:

	    using iterator_category = std::random_access_iterator_tag;
	    using value_type = T;
	    using difference_type = std::ptrdiff_t;
	    using pointer = T*;
	    using reference = T&;

	public:
	    GTUIterator(T* ptr = nullptr) : _ptr(ptr) {}
	    GTUIterator(const GTUIterator& rightSide) : _ptr(rightSide._ptr) {}
	    
	    T& operator*(){return *_ptr;}
	    T* operator->(){return _ptr;}

	    GTUIterator& operator++()   {_ptr++; return *this;}         //prefix
	    GTUIterator& operator++(int) {GTUIterator temp = *this; _ptr++; return temp;}  //postfix
	    GTUIterator& operator--()   {_ptr--; return *this;}
	    GTUIterator& operator=(const GTUIterator& rightSide) {_ptr=rightSide._ptr; return *this;}
	    //GTUIterator& operator +(int val) {auto i=0; while(i<val){_ptr++; i++; } return *this;}
	    //GTUIterator& operator -(int val){auto i=val-1; while(i>=0){_ptr--; i--; } return *this;}
 	    GTUIterator& operator+(const difference_type& movement){auto oldPtr = _ptr; _ptr+=movement; _ptr = oldPtr; return *this;}
	    GTUIterator& operator-(const difference_type& movement){auto oldPtr = _ptr; _ptr-=movement; _ptr = oldPtr; return *this;}

	    bool operator==(const GTUIterator& rightSide) {return (_ptr==rightSide._ptr);}
	    bool operator!=(const GTUIterator& rightSide) {return (_ptr!=rightSide._ptr);}

	    T* getPtr()const{return _ptr;}


	    operator bool()const
	    {
	        if(_ptr)
	            return true;
	        else
	            return false;
	    }
	    difference_type operator-(const GTUIterator& rightSide){return std::distance(rightSide.getPtr(),this->getPtr());}
	private:
	    T* _ptr;
	};
}//end of namespace
#endif