#include <iostream>
#include <algorithm>
#include <functional>
#include <string_view>

#include "gtuIterator.h"
#include "gtuIteratorConst.h"
#include "iterable.h"
#include "gtuSet.cpp"
#include "gtuSet.h"
#include "gtuVector.cpp"
#include "gtuVector.h"
#include "gtuArray.cpp"
#include "gtuArray.h"


using namespace ContainerHW6;

//Print function to see elements in the container.
template <class T>
void printContainer(Iterable<T> &container, GTUIterator<T> &iterator)
{//Prints the set with iterator
		for(iterator = container.begin(); iterator != container.end(); ++iterator)
			cout<<*iterator<<' ';
		cout<<endl;
}

void print(int x)
{
	cout << x << endl;
}

int main()
{
	////////////////////////////// ARRAY ////////////////////////////////////////////

	//Testing the array class,adding the element,erase,size,clear and empty tested.
	//Also begind and end tested in printContainer function which is uses them.

	cout<<"\n******TESTING ARRAY WITH TYPE CHAR*****\n";
	
	GTUArray<char, 4> charArray;  

	charArray[0] = 'a';
	charArray[1] = 'b';
	charArray[2] = 'c';
	charArray[3] = 'd';

	cout<<"Array is creating..\n";
	for(int i=0; i<4; ++i)
	{
		cout << i+1 <<"th element of the array is: " << charArray[i] << endl;
	}

	cout<<"Size of the Array: ";
	cout<<charArray.size()<<endl;

	cout<<"Erasing elements..\n";
	charArray.erase('a');
	cout<<"After erasing 'a':\n";
	for(int i=0; i<4; ++i)
	{
		cout << i+1 <<"th element of the array is: " << charArray[i] << endl;
	}

	cout<<"Clearing the Array..\n";
	charArray.clear();
	cout<<"After clearing the Array,Array size is:"<<charArray.size()<<endl;
	if(charArray.empty())
		cout<<"Array is empty.\n";

	cout<<"\n******TESTING Array WITH TYPE INT*****\n";

	GTUArray<int,4> intArray;
	GTUIterator<int> intPtr;

	intArray[0] = 1;
	intArray[1] = 2;
	intArray[2] = 3;
	intArray[3] = 4;

	cout<<"Array is creating..\n";
	printContainer(intArray,intPtr);

	cout<<"Size of the Array: ";
	cout<<intArray.size()<<endl;

	cout<<"Erasing elements..\n";
	intArray.erase(1);
	cout<<"After erasing 1:\n";
	printContainer(intArray,intPtr);

	intArray.erase(2);
	intArray.erase(2);
	cout<<"After erasing 2 and 3:\n";
	printContainer(intArray,intPtr);

	cout<<"Size of the Array: ";
	cout<<intArray.size()<<endl;

	cout<<"Clearing the Array..\n";
	intArray.clear();
	cout<<"After clearing the Array,Array size is:"<<intArray.size()<<endl;
	if(intArray.empty())
		cout<<"Array is empty.\n";

////////////////////////////// SET ////////////////////////////////////////////

	//Testing the set class,adding the element,erase,size,clear and empty tested.
	//Also begind and end tested in printContainer function which is uses them.
	cout<<"\n******TESTING SET WITH TYPE CHAR*****\n";
	GTUSet<char> charSet;
	GTUIterator<char> charPtr;

	charSet.addElement('e');
	charSet.addElement('c');
	charSet.addElement('a');
	charSet.addElement('f');
	charSet.addElement('d');
	charSet.addElement('z');
	charSet.addElement('m');

	cout<<"Inserting elements..\n";
	printContainer(charSet,charPtr);

	cout<<"Size of the set: ";
	cout<<charSet.size()<<endl;

	cout<<"Erasing elements..\n";
	charSet.erase('a');
	cout<<"After erasing 'a':\n";
	printContainer(charSet,charPtr);

	charSet.erase('f');
	charSet.erase('z');
	cout<<"After erasing 'f' and 'z':\n";
	printContainer(charSet,charPtr);

	cout<<"Size of the set: ";
	cout<<charSet.size()<<endl;

	cout<<"Clearing the set..\n";
	charSet.clear();
	cout<<"After clearing the set,set size is:"<<charSet.size()<<endl;
	if(charSet.empty())
		cout<<"Set is empty.\n";
	printContainer(charSet,charPtr);

	cout<<"\n******TESTING SET WITH TYPE INT*****\n";
	GTUSet<int> intSet1;
	GTUIterator<int> intPtr_1;

	intSet1.addElement(1);
	intSet1.addElement(2);
	intSet1.addElement(3);
	intSet1.addElement(4);
	intSet1.addElement(5);
	intSet1.addElement(6);
	intSet1.addElement(7);
	intSet1.addElement(8);
	intSet1.addElement(9);
	intSet1.addElement(10);

	cout<<"Inserting elements..\n";
	printContainer(intSet1,intPtr_1);

	cout<<"Size of the set: ";
	cout<<intSet1.size()<<endl;

	cout<<"Erasing elements..\n";
	intSet1.erase(3);
	cout<<"After erasing 3:\n";
	printContainer(intSet1,intPtr_1);

	intSet1.erase(6);
	intSet1.erase(8);
	cout<<"After erasing 6 and 8:\n";
	printContainer(intSet1,intPtr_1);

	cout<<"Size of the set: ";
	cout<<intSet1.size()<<endl;

	cout<<"Clearing the set..\n";
	intSet1.clear();
	cout<<"After clearing the set,set size is:"<<intSet1.size()<<endl;
	if(intSet1.empty())
		cout<<"Set is empty.\n";
/*
	cout<<"\n----------search, union, intersect function test for sets----------\n\n";
	GTUSet<int> first_set;
	GTUIterator<int> first_set_ptr;
	GTUSet<int> second_set;
	GTUIterator<int> second_set_ptr;
	GTUSet<int> union_set;
	GTUIterator<int> union_set_ptr;
	GTUSet<int> intersect_set;
	GTUIterator<int> intersect_set_ptr;
	int n = sizeof(int);

	first_set.addElement(1);
	first_set.addElement(2);
	first_set.addElement(3);

	second_set.addElement(1);
	second_set.addElement(2);

	union_set = my_union(first_set, first_set + n, second_set, second_set + n, union_set.begin());
	intersect_set = my_intersect(first_set, first_set + n, second_set, second_set + n, union_set.begin());
*/
	

////////////////////////////// VECTOR ////////////////////////////////////////////

	//Testing the vector class,adding element,erase,size,clear and empty tested.
	//Also begind and end tested in printContainer function which is uses them.

	cout<<"\n******TESTING VECTOR WITH TYPE CHAR*****\n";
	GTUVector<char> charVec;
	GTUIterator<char> charVecPtr;

	charVec.addElement('A');
	charVec.addElement('B');
	charVec.addElement('C');
	charVec.addElement('D');
	charVec.addElement('E');
	charVec.addElement('F');
	charVec.addElement('G');
	charVec.addElement('B');
	charVec.addElement('E');
	charVec.addElement('C');

	cout<<"Inserting elements..\n";
	printContainer(charVec,charVecPtr);

	cout<<"Size of the vector: ";
	cout<<charVec.size()<<endl;

	cout<<"Erasing elements..\n";
	charVec.erase('A');
	cout<<"After erasing 'A':\n";
	printContainer(charVec,charVecPtr);

	charVec.erase('D');
	charVec.erase('G');
	charVec.erase('F');
	cout<<"After erasing 'D', 'G' and 'F':\n";
	printContainer(charVec,charVecPtr);

	cout<<"Size of the vector: ";
	cout<<charVec.size()<<endl;

	cout<<"Clearing the vector..\n";
	charVec.clear();
	cout<<"After clearing the vector,vector size is:"<<charVec.size()<<endl;
	if(charVec.empty())
		cout<<"Vector is empty.\n";
	printContainer(charVec,charVecPtr);

	cout<<"\n******TESTING VECTOR WITH TYPE INT*****\n";
	GTUVector<int> intVec;
	GTUIterator<int> intVecPtr;

	intVec.addElement(10);
	intVec.addElement(20);
	intVec.addElement(30);
	intVec.addElement(40);
	intVec.addElement(50);
	intVec.addElement(60);
	intVec.addElement(70);
	intVec.addElement(80);
	intVec.addElement(90);
	intVec.addElement(100);

	cout<<"Inserting elements..\n";
	printContainer(intVec,intVecPtr);

	cout<<"Size of the vector: ";
	cout<<intVec.size()<<endl;

	cout<<"Erasing elements..\n";
	intVec.erase(30);
	cout<<"After erasing 30:\n";
	printContainer(intVec,intVecPtr);

	intVec.erase(40);
	intVec.erase(50);
	cout<<"After erasing 40 and 50:\n";
	printContainer(intVec,intVecPtr);

	cout<<"Size of the vector: ";
	cout<<intVec.size()<<endl;

	cout<<"Clearing the vector..\n";
	intVec.clear();
	cout<<"After clearing the vector,vector size is:"<<intVec.size()<<endl;
	if(intVec.empty())
		cout<<"Vector is empty.\n";

	intVec.addElement(10);
	intVec.addElement(20);
	intVec.addElement(13);
	intVec.addElement(17);
	intVec.addElement(15);

////////////////////////////// VECTOR ////////////////////////////////////////////

	cout<<"\n----------find function test for vectors----------\n\n"
		<<"Looking for find number 13 in container..\n";
	GTUIterator<int> iter;
	iter=find(intVec.begin(),intVec.end(),13);
	if (iter != (intVec.end()))
	cout << "Element found in vector container: " << *iter << '\n';
	else
	cout << "Element not found in vector container\n";

	cout<<"\n----------for_each function test for vectors----------\n\n\n";
	GTUVector<int> vectt1;
	vectt1.addElement(10);
	vectt1.addElement(20);
	vectt1.addElement(13);
	vectt1.addElement(17);
	vectt1.addElement(15);
	for_each(vectt1.begin(), vectt1.end(), print);

	cout<<"\n----------sort function test for vectors----------\n\n"
	<<"Sorted vector is..\n";
	GTUVector<int> vectt2;
	GTUIterator<int> intVecPtr2;
	vectt2.addElement(10);
	vectt2.addElement(20);
	vectt2.addElement(13);
	vectt2.addElement(17);
	vectt2.addElement(15);
	cout << "before sorting..\n";
	printContainer(vectt2,intVecPtr2);
	sort(vectt2.begin(), vectt2.end());
	printContainer(vectt2,intVecPtr2);

////////////////////////////// SET ////////////////////////////////////////////
  GTUSet<int> intSet;
	GTUIterator<int> intSetPtr;

	intSet.addElement(10);
	intSet.addElement(2);
	intSet.addElement(3);
	intSet.addElement(7);
	intSet.addElement(5);
	intSet.addElement(6);
	intSet.addElement(4);
	intSet.addElement(8);
	intSet.addElement(9);
	intSet.addElement(1);

	cout<<"\n----------find function test for sets----------\n\n"
		<<"Looking for find number 6 in container..\n";
	GTUIterator<int> itr;
	itr=find(intSet.begin(),intSet.end(),6);
	if (itr!= (intSet.end()))
	cout << "Element found in set container: " << *itr << '\n';
	else
	cout << "Element not found in set container\n";

	cout << "\n----------for_each function test for sets----------\n\n\n";
	for_each(intSet.begin(), intSet.end(), print);

	cout<<"\n----------sort function test for sets----------\n\n"
	<< "before sorting..\n";
	printContainer(intSet,intSetPtr);
	cout <<"Sorted set is..\n";
	sort(intSet.begin(), intSet.end());
	printContainer(intSet,intSetPtr);

	return 0;
}

